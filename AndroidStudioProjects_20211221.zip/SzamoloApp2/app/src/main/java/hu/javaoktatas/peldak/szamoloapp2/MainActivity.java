package hu.javaoktatas.peldak.szamoloapp2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private EditText etEgyik;
    private EditText etMasik;
    private EditText etEredmeny;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etEgyik = findViewById(R.id.etEgyik);
        etMasik = findViewById(R.id.etMasik);
        etEredmeny = findViewById(R.id.etEredmeny);
    }

    public void szamolj(View view) {
        int egyik = Integer.parseInt(etEgyik.getText().toString());
        int masik = Integer.parseInt(etMasik.getText().toString());
        int eredmeny = egyik + masik;

        etEredmeny.setText(eredmeny+"");
    }
}